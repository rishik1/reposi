#include<stdio.h>
#include<stdlib.h>
#include<time.h>
/*
structure arrayData to store pointer to interger array and other variable integer size to store size of array pointed by int pointer 
*/
typedef struct{
	int *array;
	int size;
}arrayData;

/*
Function Name           :: createArray
Input                   :: integer size
Return Value            :: pointer to structure arrayDa$
Function take size of array to be created and allocated$
*/
arrayData* createArray(int size);

/*
Function Name           :: setArray
Input                   :: pointer to structure arraytD$
Return Value            :: NONE
Function sets the value of arrayData structure variable$
*/
void setArray(arrayData *data);

/*
Function Name           :: printArray
Input                   :: pointer to structure arrayDa$
Return Value            :: None
Function printArray prints the value in structure array$
*/
void printArray(arrayData *data);

/*
Function Name           :: freeMem   
Input                   :: pointer to arrayData structu$
Return value            :: None
Function free's the memory allocated on heap to arrayDa$

*/
void freeMem(arrayData *data);


