#ifndef READINPUT_H
#define READINPUT_H

#include<stdio.h>
#include<stdlib.h>
/*
structure input to store input data float and integer values of file
*/
typedef struct{
	int a;
	float b;
}input;
/*
Function Name   :: readData    
Input           :: file pointer and pointer to integer $
Return value    :: NONE
Function readData reads from file in read only mode "r"$
and at the end closes file

*/
input* readData(char *filename,int *size);
/*
Function Name   :: printData    
Input           :: pointer to structure input and point$
Return value    :: NONE
Function prints the data in structure read from file

*/
void printData(input* data,int *size);
/*
Function Name   :: cleanData
Input           :: pointer to structure input
Return value    :: NONE
Function frees the memory allocated on heap           

*/
void cleanData(input* data);

#endif
