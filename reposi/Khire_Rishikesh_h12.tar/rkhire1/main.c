
#include "heap.h"
#include "dlinklist.h"
#include "heapApp.h"

int main(int argc,char *argv[])
{

	if(argc > 2 || argc < 1)
	{
		printf("invalid input from command line \n");
	}

	heap *heap10 =getData(argv[1]);

	printHeap(heap10);		
	
	heapClean(heap10);

  return 0;
}
