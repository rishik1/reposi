#include "heap.h"

//allocate space for tree struct and set vars
heap* createHeap()
{
	heap *h = (heap*)malloc(sizeof(heap));
	h->root = NULL;
	h->q = createDeque();
	return h;
}

//malloc new leaf and set vars
leaf* createLeaf(data *d)
{

	leaf *l = (leaf*)malloc(sizeof(leaf));
	l->parent = NULL;
	l->right = NULL;
	l->left = NULL;
	l->d = d;
	return l;
}

//malloc data and set vars
data* createData(float val,float x,float y)
{
	data* d = (data*)malloc(sizeof(data));
	d->val = val;
	d->x =x;
	d->y =y; 
	return d;
}


//add a leaf to the tree.  heap must stay complete at all times.
void addLeaf(heap *h,data *d)
{
	//We already have code from binary trees that we can use to
	//fill the heap completely, this should closely mirror that code

	//If the heap is empty
	if(h->root == NULL)
	{
		//Create a new leaf to put in the heap
		leaf* new_leaf = createLeaf(d);
		//Set the root to be the new leaf.
		//Note that left, right and parent are all already appropriately set for the root node
		h->root = new_leaf;
		
		//This is definitely a heap, as it contains only one node.
		dequePushFront(h->q, new_leaf);
	} 
	//If the heap is not empty
	else 
	{
		//Then our node will get linked to the first node in the deque (previously this was a queue)
		leaf* parent = dequeFront(h->q);

		//If the parent does not have a left child, then this new node becomes the left child
		if(parent->left == NULL)
		{
			//Create a new leaf, and link it in appropriately
			leaf* new_leaf = createLeaf(d);
			new_leaf->parent = parent;
			parent->left = new_leaf;
			//Enqueue the leaf
			dequePushBack(h->q, new_leaf);

			//Now we may have violated the max-heap property, we can fix this by using percolate up
			percolateUp(new_leaf);
		}
		//Otherwise the parent node should only have space in the right child
		else 
		{
			//Just to be sure that the left child was non-null
			assert(parent->left != NULL && parent->right == NULL);
			//Create a new leaf, and link it in appropriately
			leaf* new_leaf = createLeaf(d);
			new_leaf->parent = parent;
			parent->right = new_leaf;
			//Enqueue the leaf
			dequePushBack(h->q, new_leaf);

			//Now the front of the deque does not have any more space, so remove it
			dequePopFront(h->q);

			//Now we may have violated the max-heap property, we can fix this by using percolate up
			percolateUp(new_leaf);
		}
	}

	return;
}

//percolate up
void percolateUp(leaf *current)
{
	//Check to see if we have any place left to percolate
	if(current->parent == NULL)
	{
		//There is no place else to go
		return;
	}
	else
	{
		data* parent_data = current->parent->d;
		data* current_data = current->d;

		//If this violates the max-heap property
		if(parent_data->val < current_data->val)
		{
			//Then we should switch the data
			current->parent->d = current_data;
			current->d = parent_data;

			//Since we swapped data, we need to make sure our changes are okay on the way up
			percolateUp(current->parent);
		}
		return;
	}
}

//percolate down
void percolateDown(leaf *current)
{
	//Check to see if we have an place left to percolate
	if(current->left == NULL && current->right == NULL)
	{
		//We are a leaf, so there's no place left to go
		return;
	}
	else if(current->left != NULL && current->right == NULL)
	{
		//We can only swap with our left child since no right child exists
		data* current_data = current->d;
		data* left_data = current->left->d;

		//If this violates the max-heap property
		if(current_data->val < left_data->val)
		{
			//Then we should switch the data
			current->d = left_data;
			current->left->d = current_data;

			//Since as this point we know that left is a leaf, we know that this is a heap
		}
		return;
	}
	else 
	{
		//We can swap with either child, since both children exist
		data* current_data = current->d;
		data* left_data = current->left->d;
		data* right_data = current->right->d;

		//If this violates the max-heap property, then take the maximum of the children and swap with current
		if(current_data->val < left_data->val || current_data->val < right_data->val)
		{
			//If we got this far, then the current node is not where it needs to be, and at least
			//one of the two children is bigger than the current

			//If the biggest child is the left child
			if(left_data->val > right_data->val)
			{
				//Then current should switch data with the left child
				current->d = left_data;
				current->left->d = current_data;

				//Since we swapped data, we need to make sure our changes are okay on the way down
				percolateDown(current->left);
			}
			//Otherwise, the biggest child is the right child
			else
			{
				//Then current should switch data with the right child
				current->d = right_data;
				current->right->d = current_data;

				//Since we swapped data, we need to make sure our changes are okay on the way down
				percolateDown(current->right);
			}
			return;
		}
		//Otherwise everything is okay
		else
		{
			return;
		}
	}
}



//get the size of the tree
int treeSize(heap *h)
{

	int size = treeSize_r(h->root);
	return(size);
}
int treeSize_r(leaf *l)
{
	int size;
	if(l ==NULL)
		return 0;
	else
	{
	size = treeSize_r(l->left) + treeSize_r(l->right) +1;
	return size;
	}

return(size);
}

//print data in in order
void inOrderPrint(heap *h)
{
	if(h->root!=NULL)
	{
	inOrderPrint_r(h->root);
	}

}
void inOrderPrint_r(leaf *l)
{
	if(l!=NULL)
	{
			if(l->left!=NULL)
			{
			inOrderPrint_r(l->left);
			}
			printf("%f %f %f\n",l->d->val,l->d->x,l->d->y);
			if(l->right!=NULL)
			{
			inOrderPrint_r(l->right);
			}
	}

}
//print data in pre order
void preOrderPrint(heap *h)
{
	if(h->root!=NULL)
	preOrderPrint_r(h->root);

}
void preOrderPrint_r(leaf *l)
{
	  if(l!=NULL)
        {
		printf("%f %f %f\n",l->d->val,l->d->x,l->d->y);

		if(l->left!=NULL && l->right!=NULL)
		{
			if(l->left->d->val > l->right->d->val)
			{
                		if(l->left!=NULL)
                		{
                			preOrderPrint_r(l->left);
               			}
                		if(l->right!=NULL)
                		{
                			preOrderPrint_r(l->right);
                		}
			}
			else
			{
				  if(l->right!=NULL)
                                {
                                        preOrderPrint_r(l->right);
                                }
                                if(l->left!=NULL)
                                {
                                        preOrderPrint_r(l->left);
                                }
			}
        	}
		else if(l->left!=NULL && l->right==NULL)
		{
			preOrderPrint_r(l->left);

		}
	}

}

//print data in post order
void postOrderPrint(heap *h)
{
	if(h->root!=NULL)
	postOrderPrint_r(h->root);

}
void postOrderPrint_r(leaf *l)
{
    if(l!=NULL)
        {
                if(l->left!=NULL)
                {
                postOrderPrint_r(l->left);
                }
                if(l->right!=NULL)
                {
                postOrderPrint_r(l->right);
                }
		printf("%f %f %f\n",l->d->val,l->d->x,l->d->y);
	}

}

//remove root. Tree must remain complete and can only be done through accessing the tree.
leaf* removeRoot(heap *h)
{
        leaf *l=h->root;
        leaf *l1=dequeBack(h->q);
    
        deque *temp=createDeque();
        dequePushFront(temp,h->root);
        while((l=dequeFront(temp))!=NULL)
        {
                if(l->left->d->val==l1->d->val || l->right->d->val==l1->d->val)
                {
			break;
		}

                if(l->left!=NULL)
                {
                        dequePushBack(temp,l->left);
                }
                if(l->right!=NULL)
                {
                        dequePushBack(temp,l->right);
                }
                dequePopFront(temp);
        }
	dequePopBack(h->q);

        if(l->left==l1)
        {
		l->left=NULL;
	}
        if(l->right==l1)
        {
		l->right=NULL;
	}

        l=h->root;
        l1->left=h->root->left;
        l1->right=h->root->right;

        h->root=l1;
	l->left = NULL;
	l->right= NULL;

	dequeClean(temp);

	percolateDown(h->root);
	
	if(debug ==1)
        {
		inOrderPrint(h);
		printf("\n");
        }

        return l;


}

/**
Note that since we're using a deque this becomes easier. To remove the root, we have to
take the last leaf. We know where the last leaf is, and we can find out whether or not
its parent is in the "free space deque" through the parent pointer. If when we move the
last leaf we have to add the last leaf's parent back into the deque, then the deque
allows us to do that, where a queue would not.
  **/


//check to see if tree is balanced.  if balanced return 1 and if not return -1.
int balancedTree(heap *h)
{
	if(h->root == NULL)
	return 1;

	if(h->root->left == NULL && h->root->right)
	return 1;
	int size1 = treeSize_r(h->root->left);
 	if(debug ==1)
        {
		printf("\nsize of left sub tree :: %d",size1); 
        }

	int size2 = treeSize_r(h->root->right);
	if(debug ==1)
        {
		 printf("\nsize of left sub tree :: %d",size2); 
        }

	if(size1 == size2)
	return 1;

	
return(-1);

}

/*
Name		:: treeClean
Input		:: pointer to tree
Return's	:: None
clean's memory allocation on heap by cleaning recursively
*/
void heapClean(heap *t)
{
	heapClean_r(t->root);
	dequeClean(t->q);
	free(t);

}

/*
Name            :: heapClean_r
Input           :: pointer to leaf
Return's        :: None
cleans the heap recursively called from heapClean
*/
void heapClean_r(leaf *l)
{
	if(l != NULL)
	{
		heapClean_r(l->left);
		heapClean_r(l->right);

		free(l->d);
		free(l);
	}

}

/*
Name            :: heapPrint
Input           :: pointer to leaf
Return's        :: None
print the heap int the sorted order of distance==="val"
*/
void heapPrint(heap *h)
{
int size = treeSize(h); 
	int i=0;

	str_val *array = (str_val *)malloc(size*sizeof(str_val));
	leaf *lf = NULL;
        deque *temp = createDeque();
        dequePushFront(temp,h->root);
		
	while( ((lf = dequeFront(temp)) != NULL) && i< 10)
        {       
                dequePushBack(temp,lf->left);       
                dequePushBack(temp,lf->right); 
                array[i].val = lf->d->val;
		array[i].x = lf->d->x;
		array[i].y = lf->d->y;
                dequePopFront(temp);
	i++;
        }
	dequeClean(temp);
	insertionSort(array,size);

	for(i=0;i<size;i++)
	{
		printf("%f %f %f\n",array[i].val,array[i].x,array[i].y);
	}

free(array);

}

/*
Name            :: insertionSort              
Input           :: pointer to str_val array == which is structure that has Distance x and y coordinates
Returns         :: None
 sort the array generated from print Heap
*/
void insertionSort(str_val* arr, int size)
{
	int i=1;
	int j=0;
	float temp = 0;
	float x_temp=0;
	float y_temp=0;

	for(i=0;i<size;i++)
	{
		temp = arr[i].val;
		x_temp = arr[i].x;
		y_temp = arr[i].y;

		for(j=i-1;j>=0;j--)
		{
			if(temp > arr[j].val)
			{
				break;
			}
			else
			{
				arr[j+1].val = arr[j].val;
				arr[j+1].x = arr[j].x;
				arr[j+1].y = arr[j].y;
			}
		}
		arr[j+1].val = temp;
		arr[j+1].x = x_temp;
		arr[j+1].y = y_temp;
	}	

}
