#include "heapApp.h"
#include <math.h>

/*
Name		:: getData
Input		:: pointer to cahr array filename
Returns		:: pointer to heap
The file will be used to read in data from a text file and the heap returned should have the 10 coordinates closest to the origin.
 The text file will be entered on the command line. Hint: Most of the functions will be called in this function
*/
heap* getData(char *file)
{
	int i=0;
	float x;
	float y;
	float distance;
	FILE *fp = fopen(file,"r");

        if(fp == NULL)
        {
                printf("Error Opening file or file not found!!!\n");
                exit(0);
       }

	heap *h =createHeap();
	data *d = NULL;
	leaf *temp =NULL;

	while(fscanf(fp,"%f %f",&x,&y)!=EOF)
        {
		#if debug1
			printf("\nx::%f  y:::%f",x,y);
		#endif
		distance = calculateDistance(x,y);
		#if debug1	
			printf("  distance :: %f\n",distance);
		#endif

		if(i<10)
		{
			d = createData(distance,x,y);
			addLeaf(h,d);
		}
		else if(distance < h->root->d->val)
		{
			temp = removeRoot(h);
			free(temp->d);
			free(temp);
			d = createData(distance,x,y); 
                        addLeaf(h,d);
		}
	i++;
        }
	#if debug1
		inOrderPrint(h);
		printf("\n");
	#endif

fclose(fp);
return(h);
}

/*
Name		:: printHeap
Input		:: pointer to heap
Returns		:: None
 This function will print the heap in order. The print out should look like: "distance" "x coordinate" "y coordinate". For example: 
2.51 1.2 2.2 
3.97 -2.2 3.3 
6.92 5.5 -4.2 
*/
void printHeap(heap* h)
{
	heapPrint(h);
}

/*
Name		:: calculateDistance
Input		:: float
Returns		:: float
This function will take in x and y values and calculate the distance away from the origin.
 The formula that you will use is the 2-dimensional Euclidean plane equation. The formula is given as follows: 
distance = sqrt((x-0)^2 + (y-0)^2)
*/
float calculateDistance(float x, float y)
{
	float distance =0;
	
	if(x<0)
	x = (-1*x);

	if(y<0)
	y = (-1*y);

	distance = sqrtf((x*x)+(y*y));

return(distance);
}




