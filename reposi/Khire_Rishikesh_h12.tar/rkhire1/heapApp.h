#ifndef HEAPAPP_H
#define HEAPAPP_H
#include "heap.h"
#include<stdlib.h>
#include <math.h>

#define debug1 0
/*
Name            :: getData
Input           :: pointer to cahr array filename
Returns         :: pointer to heap
The file will be used to read in data from a text file and the heap returned should have the 10 coordinates closest to the origin.
 The text file will be entered on the command line. Hint: Most of the functions will be called in this function
*/

heap* getData(char *file);

/*
Name            :: printHeap
Input           :: pointer to heap
Returns         :: None
 This function will print the heap in order. The print out should look like: "distance" "x coordinate" "y coordinate". For example: 
2.51 1.2 2.2 
3.97 -2.2 3.3 
6.92 5.5 -4.2 
*/

void printHeap(heap* h);

/*
This function will take in x and y values and calculate the distance away from the origin.
 The formula that you will use is the 2-dimensional Euclidean plane equation. The formula is given as follows: 
distance = sqrt((x-0)^2 + (y-0)^2)
*/

float calculateDistance(float x, float y);

#endif
