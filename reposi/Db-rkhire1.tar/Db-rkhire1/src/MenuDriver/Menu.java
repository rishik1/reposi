package MenuDriver;

import java.sql.Connection;
import java.util.Scanner;

import com.DeleteStudent;
import com.DropClasses;
import com.Enrollement;
import com.InsertIntoStudent;
import com.viewClassDetails;
import com.viewCourses;
import com.viewPreReqCourses;
import com.viewTabels;

import oracle.jdbc.pool.OracleDataSource;


public class Menu {
	OracleDataSource ds =null;
	Connection conn =null;
	Scanner input;
	
	public Menu(OracleDataSource ds2, Connection conn2)
	{
		ds =ds2;
		conn =conn2;
		input =new Scanner(System.in);
	int choice = -1;
		
		while(true)
		{
		System.out.println();
		System.out.println("------------------------MENU---------------------------");
		System.out.println();
		System.out.println("\t 1 View Tables");
		System.out.println("\t 2 Insert new Student");
		System.out.println("\t 3 Courses taken by a Specific Student");
		System.out.println("\t 4 Prerequisites of a course");
		System.out.println("\t 5 Detalis of a Class"); 
		System.out.println("\t 6 Add a new Student to a Class");
		System.out.println("\t 7 Student Want to Drops a Class");
		System.out.println("\t 8 Delete a Student Record ");
		System.out.println("\t 9 Exit");
		System.out.println("Please Enter your Choice   :::");
		
		choice = input.nextInt();
		
		switch(choice)
		{
		case 1:
			viewTabels all_tables = new viewTabels(conn);
			all_tables.all_tablesMenu();
			break;
		case 2:
			InsertIntoStudent insertStudent=new InsertIntoStudent(conn);
			insertStudent.insertIntoStudentTable();
			break;
		case 3:
			viewCourses studentCourses =new viewCourses(conn);
			studentCourses.printCoursesOfStudent();
			break;
		case 4:
			viewPreReqCourses preReqOf=new viewPreReqCourses(conn);
			preReqOf.printPreReqOf();
		
			break;
		case 5:
			viewClassDetails class_details = new viewClassDetails(conn);
			class_details.printClassDetailsOf();
			break;
		case 6:
			Enrollement enrollStudent=new Enrollement(conn);
			enrollStudent.enrollStudentInto();
			break;
		case 7:
			DropClasses dropClass=new DropClasses(conn);
			dropClass.dropAclassOf();
			break;
		case 8:
			DeleteStudent del=new DeleteStudent(conn);
			del.delete_student();
			break;
		case 9: 
			System.out.println("EXITING........");
			System.exit(0);
			break;
		default: System.out.println("WRONG INPUT !!");
		     break;
				
		}
		
		}//while ends
	}

}
