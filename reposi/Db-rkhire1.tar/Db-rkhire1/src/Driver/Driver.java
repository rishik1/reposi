package Driver;

import MenuDriver.Menu;
import oracle.jdbc.pool.OracleDataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class Driver {

	public static void main(String[] args)throws SQLException {
		//String a = args[0];
		
		try{
			
			OracleDataSource ds = new oracle.jdbc.pool.OracleDataSource();
			ds.setURL("jdbc:oracle:thin:@grouchoIII.cc.binghamton.edu:1521:ACAD111");
			Scanner input =new Scanner(System.in);
			System.out.print("Enter the User Name ::");
			String user = input.nextLine();
			System.out.print("Enter the Password ::");
			String password = input.nextLine();   // fro eclipse
			//String password = new Password().passwordSet();
			
			Connection conn = ds.getConnection(user, password);
			Menu userMenu = new Menu(ds,conn);
			conn.close();
		}
		catch(SQLException e)
		{
			System.out.println("SQLERROR "+ e.getMessage());
		}
		catch(Exception e1)
		{
			System.out.println("Error "+e1.getMessage());
		}
	}

}
