package Driver;

import java.io.Console;

public class Password {

public String passwordSet()
{
	  Console console = System.console();
	  
	    if (console == null) {
	        System.out.println("Couldn't get Console instance");
	        System.exit(0);
	    }

	    console.printf("password%n");
	    char passwordArray[] = console.readPassword("Enter your secret password: ");
	    console.printf("Password entered was: %s%n", new String(passwordArray));
	    
	    return (new String(passwordArray));
}
}
