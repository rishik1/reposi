package com;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import oracle.jdbc.OracleTypes;
import oracle.jdbc.oracore.OracleType;

public class Enrollement {
	Connection conn=null;
	CallableStatement cs=null;
	Scanner inputRdr;
	
	public Enrollement(Connection connect) {
		conn = connect;
		inputRdr=new Scanner(System.in);
	}

	public void enrollStudentInto() {
		String studentId =null;
		String classId =null;
		
		System.out.println("Enter the STUDENT ID to enroll :: ");
		studentId =inputRdr.nextLine();
		System.out.println("Enter the CLASS ID to enroll in ::");
		classId = inputRdr.nextLine();
		
		try {
			cs = conn.prepareCall("{call student_system.enroll_student(?,?,?)}");
			cs.setString(1, studentId);
			cs.setString(2, classId);
			cs.registerOutParameter(3, OracleTypes.INTEGER);
			cs.execute();
			
			int registeredClasses = cs.getInt(3);
			if(registeredClasses == 3)
			{
				System.out.println("Student "+studentId +" is Over Loaded !!");
			}
			conn.commit();
				
			System.out.println("student Enrolled!!");
			System.out.println("-------------------------------------------------");
			cs.close();
		}
		catch (SQLException e) {
			System.out.println("ERROR "+e.getMessage());
			//System.exit(0);		
		}
		catch(Exception e1)
		{
				System.out.println("ERROR"+e1.getMessage());
				System.exit(0);
		}
	}

}
