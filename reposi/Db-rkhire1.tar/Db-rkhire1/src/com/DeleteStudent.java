package com;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class DeleteStudent {
	Connection conn=null;
	CallableStatement cs=null;
	Scanner inputRdr;
	
	public DeleteStudent(Connection connect) {
		conn = connect;
		inputRdr=new Scanner(System.in);
	}

	public void delete_student() {
		String studentId =null;
		
		System.out.println("Enetr the STUDENT ID whose record are to be DELETED ::");
		studentId =inputRdr.nextLine();
		
		try {
			cs = conn.prepareCall("{call student_system.delete_student(?)}");
			cs.setString(1,studentId);
			cs.executeUpdate();
			conn.commit();
			System.out.println("Students Records Deleted!!");
			System.out.println("-------------------------------------------------");
			cs.close();
			
		}
		catch (SQLException e) {
			System.out.println("ERROR "+e.getMessage());
		//	System.exit(0);		
		}
		catch(Exception e1)
		{
				System.out.println("ERROR"+e1.getMessage());
				System.exit(0);
		}
		
		
	}

}
