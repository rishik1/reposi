package com;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class InsertIntoStudent {

	Connection conn=null;
	CallableStatement cs=null;
	Scanner inputRdr;
	public InsertIntoStudent(Connection connect) {
	
		conn = connect;
		inputRdr=new Scanner(System.in);
	}

	public void insertIntoStudentTable() {
		
	String studentId =null;
	String firstName =null;
	String lastName =null;
	String status =null;
	Float GPA = null;
	String eMail =null;
	
		System.out.println();
		System.out.print(" Enter the SID of student ::");
		studentId = inputRdr.nextLine();
		
		System.out.println();
		System.out.print(" Enter the FIRST NAME of student ::");
		firstName = inputRdr.nextLine();
		
		System.out.println();
		System.out.print(" Enter the LAST NAME of student ::");
		lastName = inputRdr.nextLine();
		
		System.out.println();
		System.out.print(" Enter the STATUS of student ::");
		status = inputRdr.nextLine();
		
		System.out.println();
		System.out.print(" Enter the eMAIL iD of student ::");
		eMail = inputRdr.nextLine();
		
		System.out.println();
		System.out.print(" Enter the GPA of student ::");
		GPA = inputRdr.nextFloat();
		
		
		
		
		try{
			
			String inputQuery= "{call student_system.add_student(?,?,?,?,?,?)}";		
			cs = conn.prepareCall(inputQuery);
			
			cs.setString(1, studentId);
	        cs.setString(2, firstName);
	        cs.setString(3, lastName);
	        cs.setString(4, status);
	        cs.setFloat(5, GPA);
	        cs.setString(6, eMail);

	        cs.executeUpdate();
	        conn.commit();
	        System.out.println();
	        System.out.println("Student Entry Added to Database");
			System.out.println("-------------------------------------------------");	        
	        cs.close();
		
		
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
					
		//	System.exit(0);
		}
		catch(Exception e1)
		{
			System.out.println(e1.getMessage());
			System.exit(0);
			
		}
	}
}
