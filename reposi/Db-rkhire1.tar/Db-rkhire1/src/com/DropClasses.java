package com;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import oracle.jdbc.OracleTypes;

public class DropClasses {
	
	Connection conn=null;
	CallableStatement cs=null;
	Scanner inputRdr;
	
	public DropClasses(Connection connect) {
		conn = connect;
		inputRdr=new Scanner(System.in);
	}

	public void dropAclassOf() {
		String studentId=null;
		String classId =null;
		
		System.out.println("Enter the STUDENT ID ::");
		studentId=inputRdr.nextLine();
		System.out.println("ENter the CLASS ID want ot Drop");
		classId = inputRdr.nextLine();
		
			
		try {
			cs = conn.prepareCall("{call student_system.drop_student(?,?,?,?)}");
			cs.setString(1, studentId);
			cs.setString(2, classId);
			cs.registerOutParameter(3, OracleTypes.INTEGER);
			cs.registerOutParameter(4, OracleTypes.INTEGER);
			
			cs.executeUpdate();
			int totalClassesEnrolled = cs.getInt(3);
			int totalStudentEnrolled = cs.getInt(4); 
			if(totalClassesEnrolled == 1)
			{
				System.out.println("Student "+ studentId +"Now not Enrolled in any class !!");
			}
			if(totalStudentEnrolled == 1)
			{
				System.out.println("Class "+ classId +"Now has no students !!");
			}
			
			System.out.println("student class dropped!!");
			System.out.println("-------------------------------------------------");
			
			conn.commit();
			cs.close();
		}catch (SQLException e) {
			System.out.println("ERROR "+e.getMessage());
			//System.exit(0);
			
		}
		catch(Exception e1)
		{
				System.out.println("ERROR"+e1.getMessage());
				System.exit(0);
		}
		
	}

}
