package com;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import oracle.jdbc.OracleTypes;

public class viewPreReqCourses {

	Connection conn=null;
	CallableStatement cs=null;
	Scanner inputRdr;
	
	public viewPreReqCourses(Connection connect) {
		conn = connect;
		inputRdr=new Scanner(System.in);
	}

	public void printPreReqOf() {
			System.out.println();
			System.out.println("Enter the DEPT CODE  ::");
			String DeptCode = inputRdr.nextLine();
			System.out.println();
			
			System.out.println("Enter the COURSE NUMBER ::");
			String CourseNo = inputRdr.nextLine();
			int cNO = Integer.parseInt(CourseNo);
			System.out.println();
			
			
			System.out.println("Pre Req DEPT CODE----Pre Req COURSE NUMBER");

			RecursivePreqOf(cNO,DeptCode);
	}

	private void RecursivePreqOf(Integer cNo, String deptCode) {
	
		try {
			cs = conn.prepareCall("{call student_system.find_prereqs(?,?,?)}");
			cs.setString(1, deptCode);
			cs.setInt(2,cNo);
			
			cs.registerOutParameter(3, OracleTypes.CURSOR);
			cs.execute();
			ResultSet rSet =(ResultSet)cs.getObject(3);
			
			while(rSet.next())
			{
					String preReqDeptCode = rSet.getString(1);
					Integer preReqCourseNo = rSet.getInt(2);
					
					System.out.print(preReqDeptCode +"  ");
					System.out.println("\t"+preReqCourseNo);
					
					RecursivePreqOf(preReqCourseNo, preReqDeptCode);
			}
			System.out.println("-------------------------------------------------");
			
		} catch (SQLException e) {
			System.out.println("ERROR "+e.getMessage());
			//System.exit(0);
			
		}
		catch(Exception e1)
		{
				System.out.println("ERROR"+e1.getMessage());
				System.exit(0);
		}
		
	}

}
