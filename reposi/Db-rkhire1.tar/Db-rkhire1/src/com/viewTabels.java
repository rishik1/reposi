package com;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import oracle.jdbc.internal.OracleTypes;

public class viewTabels {

	Connection conn=null;
	CallableStatement cs=null;
	Scanner inputRdr;
	
	public viewTabels(Connection connect)
	{
		conn = connect;
		inputRdr=new Scanner(System.in);
	}
	
	public void all_tablesMenu() {
		
		try {

			boolean Flag = true;
			
			while(Flag ==true)
			{
			System.out.println("-------------TABLES-------------");
			System.out.println("");
			System.out.println("\t 1 STUDENTS");
			System.out.println("\t 2 CLASSES");
			System.out.println("\t 3 ENROLLMENTS");
			System.out.println("\t 4 COURSES");
			System.out.println("\t 5 PRE -REQUISITIES");
			System.out.println("\t 6 LOGS");
			System.out.println("\t 7 Show Main Menu");
			System.out.println("Please Enter Your Choice ::");
						
			int input =inputRdr.nextInt();
			
			switch(input)
			{
			case 1: showStudentTable();
						break;
			case 2: showClassesTable();
						break;
			case 3:showEnrollmentTable();
						break;
			case 4: showCourseTable();
						break;
			case 5: showPreReqTable();
						break;
			case 6: showLogTable();
						break;
			case 7:	System.out.println("Exit from printing tables......");
					Flag = false;
						break;			
			default:
					System.out.println("WRONG INPUT !!");
					Flag = false;
					break;					

			}//switch ends
	
		}//while ends
		} catch (SQLException e) {	
			System.out.println(e.getMessage());
			//System.exit(0);
		}
		catch(Exception e1)
		{
			System.out.println(e1.getMessage());
			System.exit(0);
		}
		
	}

	private void showCourseTable() throws SQLException{
		String str =null;
		ResultSet rset;
		System.out.println("");
		
		str= "{call student_system.show_courses(?)}";
		cs= conn.prepareCall(str);
		cs.registerOutParameter(1, OracleTypes.CURSOR);
		cs.execute();
		rset= (ResultSet) cs.getObject(1);
		System.out.println("DEPTCODE COURSE_NO TITLE ");
		while(rset.next())
		{
			System.out.print (rset.getString (1)+"  ");
			System.out.print (rset.getString (2)+"  ");
			System.out.println (rset.getString (3)+"  ");
		}

		System.out.println("-------------------------------------------------");
	}

	private void showEnrollmentTable() throws SQLException{
		String str =null;
		ResultSet rset;
		str= "{call student_system.show_enrollments(?)}";
		cs= conn.prepareCall(str);
		cs.registerOutParameter(1, OracleTypes.CURSOR);
		cs.execute();
		rset= (ResultSet) cs.getObject(1);
		System.out.println("ENROLLMENTS SID CLASSID LGRADE");
		while(rset.next())
		{
			System.out.print (rset.getString (1)+"  ");
			System.out.print (rset.getString (2)+"  ");
			System.out.println (rset.getString (3)+"  ");
		}

		System.out.println("-------------------------------------------------");
	}

	private void showLogTable() throws SQLException{
		String str =null;
		ResultSet rset;
		str= "{call student_system.show_logs(?)}";
		cs= conn.prepareCall(str);
		cs.registerOutParameter(1, OracleTypes.CURSOR);
		cs.execute();
		rset= (ResultSet) cs.getObject(1);
		System.out.println("LOGID TABLE TIME/DATE TABLENAME OPERATION KEYVALUE");
		while(rset.next())
		{
			System.out.print (rset.getString (1)+"  ");
			System.out.print (rset.getString (2)+"  ");
			System.out.print(rset.getString (3)+"  ");
			System.out.print(rset.getString (4)+"  ");
			System.out.print(rset.getString (5)+"  ");
			System.out.println(rset.getString (6)+"  ");
		}
		

		System.out.println("-------------------------------------------------");
	}

	private void showPreReqTable() throws SQLException{
		String str =null;
		ResultSet rset;
		str= "{call student_system.show_prerequisites(?)}";
		cs= conn.prepareCall(str);
		cs.registerOutParameter(1, OracleTypes.CURSOR);
		cs.execute();
		rset= (ResultSet) cs.getObject(1);
		System.out.println("COURSE");
		while(rset.next())
		{
			System.out.print (rset.getString (1)+"  ");
			System.out.print (rset.getString (2)+"  ");
			System.out.print (rset.getString (3)+"  ");
			System.out.println (rset.getString (4)+"  ");
		}

		System.out.println("-------------------------------------------------");
	}

	private void showClassesTable()throws SQLException {
		String str =null;
		ResultSet rset;
		str= "{call student_system.show_classes(?)}";
		cs= conn.prepareCall(str);
		cs.registerOutParameter(1, OracleTypes.CURSOR);
		cs.execute();
		rset= (ResultSet) cs.getObject(1);
		System.out.println("CLASSID COURSE_NO SECTION_NO YEAR SEMESTER LIMIT CLASSIZE");
		while(rset.next())
		{
			System.out.print (rset.getString (1)+"  ");
			System.out.print (rset.getString (2)+"  ");
			System.out.print(rset.getString (3)+"  ");
			System.out.print(rset.getString (4)+"  ");
			System.out.print(rset.getString (5)+"  ");
			System.out.print(rset.getString (6)+"  ");
			System.out.print(rset.getString (7)+"  ");
			System.out.println(rset.getString (8)+"  ");
		}
		
		System.out.println("-------------------------------------------------");
	}

	private void showStudentTable() throws SQLException{
		String str =null;
		ResultSet rset;
		str= "{call student_system.show_students(?)}";
		cs = conn.prepareCall(str);
		cs.registerOutParameter(1, OracleTypes.CURSOR);
		cs.execute();
		rset= (ResultSet) cs.getObject(1);
		System.out.println(" SID FIRSTNAME LASTNAME STATUS GPA eMAIL");
		while(rset.next())
		{
			System.out.print (rset.getString (1)+"  ");
			System.out.print (rset.getString (2)+"  ");
			System.out.print (rset.getString (3)+"  ");
			System.out.print (rset.getString (4)+"  ");
			System.out.print (rset.getString (5)+"  ");
			System.out.println (rset.getString (6)+"  ");
		}

		System.out.println("-------------------------------------------------");
	}

}
