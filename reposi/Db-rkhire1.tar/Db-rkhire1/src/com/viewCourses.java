package com;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import oracle.jdbc.OracleTypes;
import oracle.jdbc.oracore.OracleType;

public class viewCourses {

	Connection conn=null;
	CallableStatement cs=null;
	Scanner inputRdr;
	
	public viewCourses(Connection connect) {
		conn = connect;
		inputRdr=new Scanner(System.in);

	}

	public void printCoursesOfStudent() {
		String studentId  =null;
		System.out.println();
		
		System.out.println("Enter the Student ID to find Courses Taken :::");
		studentId =inputRdr.nextLine();
		
		try {
			cs = conn.prepareCall("{call student_system.find_courses_of_student(?,?)}");
			cs.setString(1, studentId);
			cs.registerOutParameter(2, OracleTypes.CURSOR);
			cs.execute();
			ResultSet rSet =(ResultSet) cs.getObject(2);
			System.out.println();
			System.out.println("SID    FIRSTNAME     COURSE");
			while(rSet.next())
			{
				String output = rSet.getString(1)+'\t'+rSet.getString(2)+'\t'+'\t'+rSet.getString(3);
				System.out.println(output);
			}

			System.out.println();
			System.out.println("-------------------------------------------------");
		cs.close();
		}
		catch (SQLException e) {
			System.out.println("ERROR "+e.getMessage());
			String errmsg=e.getMessage().split("\n")[0].split(": ")[1];
		//	System.exit(0);
			System.out.println(errmsg);
		}
		catch(Exception e1)
		{
				System.out.println("ERROR"+e1.getMessage());
				System.exit(0);
		}
		
		
	}

}
