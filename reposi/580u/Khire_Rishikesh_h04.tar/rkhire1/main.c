/*
Home Work no ::4
*/

#include<stdio.h>
#define debug 0


/*
structure equationVals has two float variables.
Variable funct1 in the structure to store calculated values for the first difference equation.
Variable funct2 for the second difference equation
*/
typedef struct{
float funct1;
float funct2;
}equationVals;

void problem1(int *);
void diff_equation1(equationVals *,int);
void diff_equation2(equationVals *,int);
void print_value(equationVals *,int);


int main(void){

int i;
int num=0;
int size =20;

	for(i=2; i <= 20; i++)	
	{
		problem1(&num);
		printf("%d\n",num);
	}


	equationVals Eqn_value[20];
	
	diff_equation1(Eqn_value,size);

	if(debug==1)
	{
		for(i=0;i<size;i++)
		printf("value f(0)=%f  value f(1)=%f \n",Eqn_value[i].funct1);
	}
	
	
	diff_equation2(Eqn_value,size);
	
	if(debug==1)
	{
		for(i=0;i<size;i++)
		printf("value f(0)=%f\n",Eqn_value[i].funct2);
	}

	
	print_value(Eqn_value,size);

return 0;

}

/*
Function Name	:: problem1
Input		:: integer pointer
The function dereferences the pointer and add 10 to it.	    
*/
void problem1(int *ptr)
{        
        *ptr = *ptr+10;
}

/*
Function Name	:: diff_equation1
Input		:: pointer to an array of equationVals ,intger size of the array.
The Function calculates the first difference equation for each value in the array.
f(x) = 5*f(x-1)/4*f(x-2)
*/

void diff_equation1(equationVals *ptr,int size)
{
int i;                  
float result;
equationVals *p = ptr;
p[0].funct1 = 1;
p[1].funct1 = 2;

        if(debug ==1)      
        {           
                printf("value of f1(0)= %f value of f1(1)=  %f\n",p[0].funct1,p[1].funct1);
        }
        
        
        for(i=2; i<20; i++)
        {            
                p[i].funct1 =(5*p[i-1].funct1)/(4*p[i-2].funct1);       
        }                  


}        

/*
Function Name   :: diff_equation2
Input           :: pointer to an array of equationVals ,intger size of the array.
The Function calculates the first difference equation for each value in the array.        
f(x) = 2*f(x-3) + 4*f(x-2) - 3*f(x-1)
*/

void diff_equation2(equationVals *ptr,int size)
{
int i;
float result;
equationVals *p = ptr;
p[0].funct2 =2;
p[1].funct2 =4;
p[2].funct2 =3; 
		
        if(debug ==1)
        {
                printf("value of f2(0)= %f  value of f2(1) =%f  value of f2(2) =%f\n",p[0].funct1,p[1].funct2);
        }
        for(i=3; i<20; i++)
        {
                p[i].funct2 = (2*p[i-3].funct2)+(4*p[i-1].funct2)-(3*p[i-2].funct2);
        }

}


/*
Function Name   :: print_value
Input           :: pointer to an array of equationVals ,intger size of the array.
The function print out each value calculated for the first equation and
then calculated by the second equation.
*/
void print_value(equationVals *ptr,int size)
{
int i;
printf("\n");

        for(i=2;i<size;i++)
        {
                printf("%f\n",ptr[i].funct1);
        }
        printf("\n");
        
        for(i=3;i<size;i++)
        {
                printf("%f\n",ptr[i].funct2);
        }

}


