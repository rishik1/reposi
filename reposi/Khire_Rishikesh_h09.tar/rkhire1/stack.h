#ifndef _STACK_H_
#define _STACK_H_
#include "dlinklist.h"

// structure forstack with a pointer to double linklist
typedef struct
{
  dlinklist *ll;
}stack;
//function to create stack from doublelinklist and initialize  variable to NULL
stack* createStack();
//function to push data in the stack from top
void stackPush(stack *s,data *d);
// functiom to pop data from stack 
data* stackPop(stack *s);
// function to print data in the stack
void stackPrint(stack *s);
// function to calculate length of stack
int stackSize(stack *s);
// function to clean the stack
void stackClean(stack *s);

#endif
