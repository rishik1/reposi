#include "stack.h"

/*
Name		:: createStack
Input		:: None
Return's	:: pointer to satck
//function to create stack from doublelinklist and initialize  variable to NULL
*/
stack* createStack()
{
	stack *s =  (stack *)malloc(sizeof(stack));
	s->ll = createlinklist();
	return(s);
}
/*
Name            :: stackPush
Input           :: pointer to stack, pointer to data
Return's        :: None
//function to push data in the stack from top
*/

void stackPush(stack *s,data *d)
{
	addFront(s->ll,d);

}
/*
Name            :: stackPop
Input           :: pointer to satck
Return's        :: pointer to data
functiom to pop data from stack
*/

data* stackPop(stack *s)
{
	data *dat = popFront(s->ll);
return(dat);

}

/*
Name            :: stackPrint
Input           :: pointer to satck
Return's        :: None
function to print data in the stack
*/

void stackPrint(stack *s)
{
	stack *temp = createStack();
	data *d =NULL;
	while((d =popFront(s->ll)) !=NULL)
	{
		printf("%c\n",d->val);
		addFront(temp->ll,d);
	}
	while((d = popFront(temp->ll)) !=NULL)
	{
		addFront(s->ll,d);
	}
	stackClean(temp);
}

/*
Name            :: stackSize
Input           :: pointer to satck
Return's        :: intger 
function to calculate length of stack
*/

int stackSize(stack *s)
{
	stack *temp = createStack();
        data *d =NULL;
	int count =0;
        while((d =popFront(s->ll)) !=NULL)
        {
                count++;
                addFront(temp->ll,d);
        }
        while((d =popFront(temp->ll)) !=NULL)
        {

                addFront(s->ll,d);
        }
	stackClean(temp);
	return (count);
}

/*
Name            :: stackClean
Input           :: pointer to stack
Return's        :: None
function to clean the stack
*/

void stackClean(stack *s)
{
	cleanList(s->ll);
	free(s);
}


