#include "postfix.h"

/*
Name		:: parseData
Input		:: pointer to char array from command line
Retur's		:: pointer to queue
his function takes in a string of numbers and math operations and parse the string so that each element in the string,
 both numbers and operators, are entered into a queue. 
*/
queue* parseData(char *eq)
{

	queue *q = createQueue();
	int i=0;
	data *dat =NULL;
	while(eq[i]!= '\0')
	{
		dat = createData(eq[i]);
		queuePush(q,dat);
	i++;
	}
	
	#if debug
	queuePrint(q);
	#endif 
return q;	
}

/*
Name            :: operation
Input           :: int operand 1 int operan2 int operand3
Return's         :: integer 
This function evaluate the operation takin 2 operands and operator as input and returns it
*/
int operation(int op1, int op2 ,char opr)
{
		int result = 0;

	        if(opr == '+')
                result = op1 + op2;
                
		else if(opr == '-')
                result = op1 - op2;
                
		else if(opr == '*')
                result = op1 * op2;
                
		else if(opr == '/')
		{	
			if(op2 == 0)
			{	
				printf("\n Wrong input entered or div by zero\n");
				exit(0);
			}
			result = op1/op2;
		}
                
		else if(opr == '%')
                result = op1%op2;
              
		else if(opr == '^')
                result = pow(op1,op2);

		#if debug 
			printf("result of operation ::%d",result);
		#endif
return result;
}

/*
Name            :: preFix
Input           :: pointer to queue
Retur's         :: integer
his function takes in the queue filled with the parsed equation data and evaluate the equation with prefix math.
 The result (that is returned) will be the evaluation of the equation
*/

int preFix(queue* q)
{
	int result =0;
	data *dat=NULL;
	int op1 = 0;
	int op2 = 0;
	char opr;
	queue *temp = createQueue();

		dat = queuePop(q);
		op1 = dat->val - '0';
		queuePush(temp,dat);
	       
		dat = queuePop(q);
		opr = dat->val;
		queuePush(temp,dat);

		dat = queuePop(q);
		op2=dat->val-'0';
		queuePush(temp,dat);

		result = operation(op1,op2,opr);
		int size=queueSize(q);
		int i=0; 
		while((dat = queuePop(q)) != NULL)
		{
			opr = dat->val;
			queuePush(temp,dat);
			i++;

			if(i<size)
			{
				dat = queuePop(q);
				op2=dat->val-'0';
				queuePush(temp,dat);
				result = operation(result,op2,opr);
				i++;
			}
			if(i>=size)
			{
				break;
			}
		}
		i=0;
		while((dat = queuePop(temp))!=NULL)
		{
			i++;
			queuePush(q,dat);
		}
		
		#if debug
		queuePrint(q);
		#endif
queueClean(temp);
return result;			
		
}
/*
Name            :: postFix
Input           :: pointer to queue
Return's        :: integr 
This function takes in the queue filled with the parsed equation data and evaluate the equation with postfix math.
The result (that is returned) will be the evaluation of the equation, and should be printed out in the main function
*/

int postFix(queue* q)
{
	int result =0;
	int op1 = 0;
	int op2 = 0;
	char opr;
	stack *s= createStack();
	data *dat =NULL;

	int size=queueSize(q);
	int i=0;

	while((dat = queuePop(q))!= NULL)
	{
		stackPush(s,dat);
		i++;
		if(i==size)
		{
			break;
		}
	}

		#if debug
		stackPrint(s);
		#endif



                dat = stackPop(s);
                op2 = dat->val -'0';
		free(dat);
                dat = stackPop(s);
                opr = dat->val;
		free(dat);
	
                dat = stackPop(s);
		op1 = dat->val -'0';
		free(dat);
                result = operation(op1,op2,opr);
		int size1 = stackSize(s);
		i=0;
		#if debug
		printf("Size:%d\n",size1);
		#endif

                while((dat = stackPop(s)) != NULL)
                {
                        opr = dat->val;
			free(dat);
			i++;
			if(i<size1)
			{
                        	dat = stackPop(s);
				op1 = dat->val -'0';
				free(dat);
                        	result = operation(op1,result,opr);
				i++;
			}
			if(i==size1)
			{
				break;
			}
                }
		
stackClean(s);
return result;                
}


