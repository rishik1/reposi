#include "queue.h"

/*
Name		:: createQueue
Input		:: None
Return's	:: pointer to queue
creates queue on heap and assign values to NULL
*/
queue* createQueue()
{
	queue *q =  (queue *)malloc(sizeof(queue));
        q->ll = createlinklist();
        return(q);

}

/*
Name            :: queuePush
Input           :: pinter to queue, pointer to data
Return's        :: None
//Pushes data on queue 'q' from back 
*/

void queuePush(queue *q,data *d)
{
	addBack(q->ll,d);
}

/*
Name            :: queuePop
Input           :: pointer to queue
Return's        :: pointer to data
//pop data from queue 'q' from front
*/

data* queuePop(queue *q)
{
	data *dat = popFront(q->ll);
	return(dat);
}

/*
Name            :: queueSize
Input           :: pointer to queue
Return's        :: integer as size
function calculates size of queue as integer

*/

int queueSize(queue *q)
{
	queue *temp = createQueue();
	int count = 0;
	data *d = NULL;
	while((d = popFront(q->ll))!=NULL)
	{
		addBack(temp->ll,d);
		count++;
	} 
	while((d = popFront(temp->ll))!=NULL)
	{
		addBack(q->ll,d);
	} 
queueClean(temp);
return(count);
}

/*
Name            :: queuePrint
Input           :: pointer to queue
Return's        :: None
function prints all elements of queue

*/

void queuePrint(queue *q)
{
  queue *temp = createQueue();
        data *d = NULL;
        while((d = popFront(q->ll))!=NULL)
        { 
	printf("\n %c",d->val);
        addBack(temp->ll,d);  
        } 
        while((d = popFront(temp->ll))!=NULL) 
        { 
        addBack(q->ll,d);
        } 
queueClean(temp);
}


/*
Name            :: queueClean
Input           :: pointer to queue
Return's        :: None
function cleans all the memeory allocation on heap for queue q

*/
void queueClean(queue *q)
{
cleanList(q->ll);
free(q);
}

