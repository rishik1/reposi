
#ifndef _QUEUE_H_
#define _QUEUE_H_

#include "dlinklist.h"
// structure to store double linklist
typedef struct
{
  dlinklist *ll;
}queue;

//creates queue on heap and assign values to NULL
queue* createQueue();
//Pushes data on queue 'q' from back 
void queuePush(queue *q,data *d);
//pop data from queue 'q' from front
data* queuePop(queue *q);
//function calculates size of queue as integer
int queueSize(queue *q);
//function prints all elements of queue
void queuePrint(queue *q);
//function cleans all the memeory allocation on heap for queue q
void queueClean(queue *q);
#endif
