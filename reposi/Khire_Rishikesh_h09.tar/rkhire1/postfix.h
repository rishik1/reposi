#ifndef POSTFIX_H
#define POSTFIX_H

#include<stdio.h>
#include<math.h>
#include "stack.h"
#include "queue.h"
#include "dlinklist.h"
#define debug 0

/*his function takes in a string of numbers and math operations and parse the string so that each element in the string,
 both numbers and operators, are entered into a queue. 
*/
queue* parseData(char *eq);
/*
his function takes in the queue filled with the parsed equation data and evaluate the equation with prefix math.
 The result (that is returned) will be the evaluation of the equation
*/
int preFix(queue* q);
/*
This function takes in the queue filled with the parsed equation data and evaluate the equation with postfix math.
The result (that is returned) will be the evaluation of the equation, and should be printed out in the main function
*/
int postFix(queue* q);
//This function evaluate the operation takin 2 operands and operator as input and returns it
int operation(int op1,int op2,char opr);

#endif
