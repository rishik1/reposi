#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include "linklist.h"
#define debug1 0
/* This function open a file for reading. Then it will load the data for each employee into a data element and load it into a linkList.
 Finally the linkList is returned.
*/
linkList* loadData(char *fileName);
/*
This function count everyone in the linkList who has the same first name as the input variable first. The counted number is returned
*/
int countFirstName(linkList *ll, char *first);
/*
This function remove from the linkList anyone who has the same last name as the input variable last.
*/
void removeLastName(linkList *ll, char *last);
/*
This function remove from the linkList anyone who has the same last name as the input variable last.
*/
void removeFirstName(linkList *ll,char *first);
/*
This function cleans memory
*/
void clean_emp(linkList *ll);
#endif

