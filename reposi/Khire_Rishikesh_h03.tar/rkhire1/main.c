/*Name :: Rishikesh Khire
   HOME WORK :: 3
*/

#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include<math.h>

#define debug 0
#define PI 3.1415926

typedef struct{			//Structure coordinate to define point in X-y plane.
float x;
float y;
}coordinate;

/*
Function name :: getRandom()
Return Type   :: float
Function generate random number from range -1.00 to 1.00   
*/
float getRandom(){

	int result;
	float z;
	result = rand()%201 - 100;	
	z = ((float)result/100.0f);
	return z;
}

/*
Function Name :: generateCoor
Return Type   :: coordinate
Function Generates point in X-Y plane 
*/
coordinate generateCoor(){
	coordinate point;
	
	point.x = getRandom();
	point.y = getRandom();
		
		if(debug == 1)
		{
			printf("\n X =%.2f Y= %.2f",point.x,point.y);
		}
	return(point);
}


/*
Function Name	:: getDistance
INPUT 		:: coordinate point
Return type	:: float
Function Calculated Distance and returns calculated distance
*/
float getDistance(coordinate point){

	float distance;

	distance = sqrt((point.x*point.x) + (point.y*point.y));       // distance formula
		if(debug == 1)
		{
			printf("\n distance = %f",distance);
		}

	return distance;
}

/*
Function Name   :: isIN
INPUT		:: float distance
Return Type	:: int
Checks if the point lie inside the Circle of Radius = 1
*/

int isIn(float distance){

	if(distance <= 1)
	{
		return 1;
	}
	else
		return 0;

}

/*
Function Name	:: calc Error
INPUT		:: float calculated float origanal
Return Type 	:: float
Function takes in calculated value of PI and Orignal value of PI
and calculates and returns Error = |calulated - origanl|
*/

float calcError(float calculated,float orignal)
{
	if(calculated - orignal <0)
	{
		return (orignal - calculated);
	}
	else
		return (calculated - orignal);

}

/*
Main Function
*/
int main(void){
	srand(time(NULL));			//Avoids repeated value generated from rand()
	int total = 0;				// total to count number of Darts thrown
	int count = 0;				// counter to count number of Darts inside circle
	coordinate point;
	float distance;
	float calcPI;
	float err;
		
	do{
		total++;
		point = generateCoor();	
		distance = getDistance(point);

			if(isIn(distance))
			{
					count++;
			}
		if(debug == 1)
		{
			printf("\ncount :::::::::%d",count);
			printf("\ntotal :::::::::%d",total);
		}
	
		calcPI = (float)(4*count)/total;	// calculated value of PI = (4*Darts_inside)/total	
		err = calcError(calcPI,PI);

	}while(err > 0.0001);				//Loop till Error is greater than 0.0001(Error Tolerance)
	
	printf("%f %f\n",PI , calcPI);	
	printf("%f\n", err);

		
	return 0;
}

