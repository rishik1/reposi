#include "btree.h"


btree* create_btree()
{
  btree *tree = (btree*)malloc(sizeof(btree));
  tree->root = NULL;
  return tree;
}
  
		   

void add_btree(data* d,btree *tree)
{




}
