#ifndef _BTREE_H_
#define _BTREE_H_

#include <stdio.h>
#include <stdlib.h>

typedef struct
{
  int num;
}data;

typedef struct leaf_ptr
{
  data *d;
  struct leaf_ptr *right;
  struct leaf_ptr *left;
} leaf;

typedef struct
{
  leaf* root;
}btree;


//create btree 
btree* create_btree();
void add_btree(data* d, btree* tree);

#endif
